export default  {
primaryColor: '#252525',
accent: '#363636',
placeholderColor: '#707070',
tabBarTintColor: '#5b5555',
}